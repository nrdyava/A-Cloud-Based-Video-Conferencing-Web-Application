import { Grid } from '@material-ui/core';
import React, { useEffect } from 'react';

const OpenViduComponent = () => {
  return (
    <Grid container direction="row" justify="center" alignItems="center">
      <iframe src='video.html' width={1500} height={1000}></iframe>
    </Grid>
  );
};

export default OpenViduComponent;
